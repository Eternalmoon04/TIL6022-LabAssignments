Hello!
Welcome to TIL6010!
This is a simple plain text file.